package com.lfbs.android.sqlite.manager.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.lfbs.android.sqlite.R;
import com.lfbs.android.sqlite.manager.database.DatabaseQueryResult;
import com.lfbs.android.sqlite.manager.view.SQLiteQueryResultRowView;

public class SQLiteQueryResultAdapter extends BaseAdapter
{
	private final Context mContext;
	private LayoutInflater layoutInflater;
	private DatabaseQueryResult databaseQueryResult;

	static class ViewHolder 
	{
		public SQLiteQueryResultRowView queryResultRow;
	}	

	public SQLiteQueryResultAdapter(Context context,DatabaseQueryResult databaseQueryResult)
	{
		mContext = context;
		setDatabaseQueryResult(databaseQueryResult);

		setLayoutInflater((LayoutInflater)mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE));
	}

	public LayoutInflater getLayoutInflater()
	{
		return layoutInflater;
	}

	public void setLayoutInflater(LayoutInflater value)
	{
		layoutInflater = value;
	}

	@Override
	public int getCount()
	{
		return getDatabaseQueryResult().getRowCount();
	}

	@Override
	public Object getItem(int position)
	{
		return getDatabaseQueryResult().getDataRow(position);
	}

	@Override
	public long getItemId(int position)
	{
		@SuppressWarnings("unchecked")
		ArrayList<String> dataRow = (ArrayList<String>)getItem(position);

		return (Long.parseLong(dataRow.get(0)));
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		SQLiteQueryResultRowView sqliteQueryResultRowView;

		sqliteQueryResultRowView = new SQLiteQueryResultRowView(mContext,getLayoutInflater().inflate(R.layout.sqlite_query_result_row, null),
				getDatabaseQueryResult(),position);

		return(sqliteQueryResultRowView.getParentView());
	}

	public DatabaseQueryResult getDatabaseQueryResult()
	{
		return databaseQueryResult;
	}

	public void setDatabaseQueryResult(DatabaseQueryResult value)
	{
		databaseQueryResult = value;
	}


}
