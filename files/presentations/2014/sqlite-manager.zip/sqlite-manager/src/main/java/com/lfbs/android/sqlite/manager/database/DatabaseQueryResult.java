package com.lfbs.android.sqlite.manager.database;

import java.io.Serializable;
import java.util.ArrayList;

import android.database.Cursor;
import android.util.Log;

public class DatabaseQueryResult implements Serializable
{
	public static final int COLUMN_TYPE_NULL = 0;
	public static final int COLUMN_TYPE_INT = 1;
	public static final int COLUMN_TYPE_STRING = 3;

	private static final long	serialVersionUID	= 1L;

	private String tableName;
	private ArrayList<String> columnNames;
	private ArrayList<Integer> columnTypes;
	private ArrayList<ArrayList<String>> dataRows;

	public DatabaseQueryResult()
	{
		setTableName(new String());
		setColumnNames(new ArrayList<String>());
		setColumnTypes(new ArrayList<Integer>());
		setDataRows(new ArrayList<ArrayList<String>>());
	}

	public String getTableName()
	{
		return tableName;
	}

	public void setTableName(String value) 
	{
		tableName = value;
	}

	public ArrayList<ArrayList<String>> getDataRows()
	{
		return dataRows;
	}

	public void setDataRows(ArrayList<ArrayList<String>> value)
	{
		dataRows = value;
	}

	public ArrayList<Integer> getColumnTypes()
	{
		return columnTypes;
	}

	public void setColumnTypes(ArrayList<Integer> value)
	{
		columnTypes = value;
	}

	public ArrayList<String> getColumnNames()
	{
		return columnNames;
	}

	public void setColumnNames(ArrayList<String> value)
	{
		columnNames = value;
	}

	public int getRowCount()
	{
		return(dataRows != null ? dataRows.size() :  0);
	}

	public int getColumnCount()
	{
		return(columnNames != null ? columnNames.size() :  0);
	}

	public String getColumnData(int row,int col)
	{
		String colData = "";
		if((row >= 0) && (row < getRowCount()) &&  
				(col >= 0) && (col < getColumnCount()))
		{
			colData = getDataRows().get(row).get(col);
		}
		else
		{
			Log.println(Log.ERROR, getClass().toString(),"getColumnData(" + row + "," + col + ") call out of bounds, returning blank.");
		}

		return(colData);
	}

	public Integer getColumnType(int col)
	{
		Integer colType = Cursor.FIELD_TYPE_STRING;

		if((col >= 0) && (col < getColumnCount()))
		{
			colType = getColumnTypes().get(col);
		}
		else
		{
			Log.println(Log.ERROR, getClass().toString(),"getColumnType(" + col + ") call out of bounds, Cursor.String");
		}

		return(colType);
	}

	public String getColumnName(int col)
	{
		String colName = "";

		if((col >= 0) && (col < getColumnCount()))
		{
			colName = getColumnNames().get(col);
		}
		else
		{
			Log.println(Log.ERROR, getClass().toString(),"getColumnType(" + col + ") call out of bounds, returning blank.");
		}

		return(colName);
	}

	public ArrayList<String> getDataRow(int row)
	{
		ArrayList<String> dataRow = new ArrayList<String>();

		if((row >= 0) && (row < getRowCount()))
		{
			dataRow = getDataRows().get(row);
		}
		else
		{
			Log.println(Log.ERROR, getClass().toString(),"getDataRow(" + row + ") call out of bounds, returning blank.");
		}

		return(dataRow);
	}

}
