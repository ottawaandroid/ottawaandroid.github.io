package com.lfbs.android.sqlite.manager.activity;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.view.Menu;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;

import com.lfbs.android.sqlite.R;
import com.lfbs.android.sqlite.manager.fragment.ui.SQLiteQueryResultFragment;
import com.lfbs.android.sqlite.manager.fragment.ui.SQLiteTableSQLFragment;
import com.lfbs.android.sqlite.manager.fragment.ui.SQLiteTableSummaryFragment;

public class SQLiteTableActivity extends Activity implements OnTabChangeListener
{
	public static final String PARM_TABLE_NAME = "SqliteTableName";

	private static final String TAB_DATA = "TabData";
	private static final String TAB_SUMMARY = "TabSummary";
	private static final String TAB_SQL = "TabSQL";

	private static final int TAB_INDX_DATA = 0;
	private static final int TAB_INDX_SUMMARY = 1;
	private static final int TAB_INDX_SQL = 2;

	private TabHost tabHost;
	private int currentTab;
	private String sqliteTableName;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sqlite_table);

		setSQLiteTableName((String)getIntent().getSerializableExtra(PARM_TABLE_NAME));
		setTitle(getTitle() + " - " + getSQLiteTableName());
		setupTabHost();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.sqlite_table, menu);
		return true;
	}

	@Override
	protected void onStart()
	{
		super.onStart();

		onTabChanged(TAB_DATA);
	}

	private void setupTabHost()
	{
		// create the TabHost that will contain the Tabs
		setTabHost((TabHost)findViewById(android.R.id.tabhost));

		getTabHost().setup();

		getTabHost().addTab(createTab(TAB_DATA,R.string.title_tab_sqlite_table_data ,R.id.tab1));
		getTabHost().addTab(createTab(TAB_SUMMARY,R.string.title_tab_sqlite_table_summary ,R.id.tab2));
		getTabHost().addTab(createTab(TAB_SQL,R.string.title_tab_sqlite_table_sql ,R.id.tab3));

		getTabHost().setOnTabChangedListener(this);
	}

	private TabSpec createTab(String tag, int tabTitleId, int tabContentId) 
	{
		TabSpec tabSpec = getTabHost().newTabSpec(tag);
		tabSpec.setIndicator(getResources().getText(tabTitleId));
		tabSpec.setContent(tabContentId);

		return tabSpec;
	}

	public String getSQLiteTableName()
	{
		return sqliteTableName;
	}

	public void setSQLiteTableName(String value)
	{
		sqliteTableName = value;
	}

	public TabHost getTabHost()
	{
		return tabHost;
	}

	public void setTabHost(TabHost value)
	{
		tabHost = value;
	}

	public int getCurrentTab()
	{
		return currentTab;
	}

	public void setCurrentTab(int value)
	{
		currentTab = value;
	}

	@Override
	public void onTabChanged(String tabId)
	{
		if(tabId.equals(TAB_DATA))
		{
			updateTab(tabId, R.id.tab1);
			setCurrentTab(TAB_INDX_DATA);
			return;
		}
		else if(tabId.equals(TAB_SUMMARY))
		{
			updateTab(tabId, R.id.tab2);
			setCurrentTab(TAB_INDX_SUMMARY);
			return;
		}
		else if(tabId.equals(TAB_SQL))
		{
			updateTab(tabId, R.id.tab3);
			setCurrentTab(TAB_INDX_SQL);
			return;
		}
	}

	private void updateTab(String tabId, int placeholder) 
	{
		FragmentManager fm = getFragmentManager();
		Fragment fragmentCurrent = fm.findFragmentByTag(tabId);

		if(fragmentCurrent == null) 
		{
			if(tabId.equals(TAB_DATA))
			{
				fragmentCurrent = new SQLiteQueryResultFragment();

				((SQLiteQueryResultFragment)fragmentCurrent).setSqlQuery("Select * from " + getSQLiteTableName());
			}
			else if(tabId.equals(TAB_SUMMARY))
			{
				fragmentCurrent = new SQLiteTableSummaryFragment();
				((SQLiteTableSummaryFragment)fragmentCurrent).setTableName(getSQLiteTableName());

			}
			else if(tabId.equals(TAB_SQL))
			{
				fragmentCurrent = new SQLiteTableSQLFragment();

				((SQLiteTableSQLFragment)fragmentCurrent).setTableName(getSQLiteTableName());
			}
		}

		fm.beginTransaction().replace(placeholder,fragmentCurrent, tabId).commit();
	}	

}
