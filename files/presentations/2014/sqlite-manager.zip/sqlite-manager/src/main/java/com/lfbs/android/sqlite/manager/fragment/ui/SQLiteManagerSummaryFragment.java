package com.lfbs.android.sqlite.manager.fragment.ui;

import java.util.ArrayList;

import android.app.Fragment;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.lfbs.android.sqlite.R;
import com.lfbs.android.sqlite.manager.adapter.SQLiteQueryResultAdapter;
import com.lfbs.android.sqlite.manager.database.DatabaseQueryResult;
import com.lfbs.android.sqlite.manager.database.SQLiteDatabaseManager;

public class SQLiteManagerSummaryFragment extends Fragment
{
	private static final String DATABASE_PRAGMA = "PRAGMA";
	private ListView sqliteTableLV;
	private SQLiteQueryResultAdapter sqliteTableDataAdapter;


	// http://www.sqlite.org/pragma.html

	private final String[] pragma = 
		{"application_id","automatic_index","busy_timeout","auto_vacuum","foreign_keys",
			"cache_size","cache_spill","case_sensitive_like","checkpoint_fullfsync",
			"collation_list","compile_options","database_list","defer_foreign_keys","encoding","foreign_key_check","foreign_key_list",
			"freelist_count","fullfsync","ignore_check_constraints","incremental_vacuum","index_info","index_list","locking_mode",
			"page_count","page_size","read_uncommitted","recursive_triggers","reverse_unordered_selects","schema_version","secure_delete",
			"user_version","writable_schema"};

	private final String[] pragmaResults = new String[pragma.length];
	private int pragmaIndx = 0;

	// UI references.
	private View statusView;
	private TextView statusMessageView;
	private Handler handler;

	public SQLiteManagerSummaryFragment()
	{
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState)
	{
		View view = inflater.inflate(R.layout.fragment_sqlite_manager_summary,container, false);
		handler = new Handler();

		return view;
	}

	@Override public void onStart()
	{
		super.onStart();

		setStatusView(getView().findViewById(R.id.sqlitemanagersummary_query_status));
		statusMessageView = (TextView) getView().findViewById(R.id.sqlitemanagersummary_status_message);

		sqliteTableLV = (ListView)getView().findViewById(R.id.sqlitemanagersummary_datalist);

		getStatusView().setVisibility(View.VISIBLE);

		new Thread(new Runnable() 
		{ 
			@Override
			public void run()
			{
				Cursor cursor = null;

				for(String prg : pragma)
				{
					showStatusMsg("Getting database pragma - " + prg);

					try
					{
						cursor = SQLiteDatabaseManager.getInstance().getSQLiteDatabase().rawQuery(DATABASE_PRAGMA + " " + prg, null);

						if (cursor.getColumnCount() > 0)
						{
							// reset the cursor
							cursor.moveToFirst();
							pragmaResults[pragmaIndx] = cursor.getString(0);
						}
					}
					catch (Exception e)
					{
						Log.println(Log.ERROR, getClass().toString(),"Error geting value for " + prg);
					}
					finally
					{
						if(cursor != null && !cursor.isClosed())
						{
							cursor.close();
						}
					}

					Log.println(Log.INFO, getClass().toString(),prg +  "  - " + pragmaResults[pragmaIndx]);
					pragmaIndx++;
				}
				hideStatusMsg();
				showResults();
			}
		}).start();
	}

	public View getStatusView()
	{
		return statusView;
	}

	public void setStatusView(View value)
	{
		statusView = value;
	}

	private void showStatusMsg(final String progressMsg)
	{
		Runnable runnable = new Runnable()
		{
			@Override
			public void run()
			{
				handler.post(new Runnable()
				{ // This thread runs in the UI
					@Override
					public void run()
					{
						statusMessageView.setText(progressMsg);
					}
				});
			}
		};
		new Thread(runnable).start();
	}

	private void hideStatusMsg()
	{
		Runnable runnable = new Runnable()
		{
			@Override
			public void run()
			{
				handler.post(new Runnable()
				{ // This thread runs in the UI
					@Override
					public void run()
					{
						getStatusView().setVisibility(View.GONE);
					}
				});
			}
		};
		new Thread(runnable).start();
	}

	private void showResults()
	{
		final DatabaseQueryResult databaseQueryResult = new DatabaseQueryResult();
		ArrayList<String> row = new ArrayList<String>();

		databaseQueryResult.getColumnNames().add("Pragma");
		databaseQueryResult.getColumnNames().add("Value");

		for(int i=0; i < pragma.length; i++)
		{
			row = new ArrayList<String>();
			row.add(pragma[i]);
			row.add(pragmaResults[i]);
			databaseQueryResult.getDataRows().add(row);
		}

		Runnable runnable = new Runnable()
		{
			@Override
			public void run()
			{
				handler.post(new Runnable()
				{ // This thread runs in the UI
					@Override
					public void run()
					{
						sqliteTableLV.setVisibility(View.VISIBLE);

						sqliteTableDataAdapter = new SQLiteQueryResultAdapter(getActivity().getApplicationContext(),databaseQueryResult);
						sqliteTableLV.setAdapter(sqliteTableDataAdapter);
					}
				});
			}
		};
		new Thread(runnable).start();
	}
}
