package com.lfbs.android.sqlite.manager.database;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.util.Log;

@SuppressLint("DefaultLocale")
public class SQLiteDatabaseTask extends AsyncTask<Void, Void, Boolean>
{
	private String sqlCommand;
	private SQLiteDatabase sqliteDatabase;
	private DatabaseQueryResult databaseQueryResult;
	private String sqlError;

	public SQLiteDatabaseTask(SQLiteDatabase sqliteDatabase)
	{
		setSQLiteDatabase(sqliteDatabase);
	}

	@Override
	protected Boolean doInBackground(Void... params)
	{
		boolean success = false;
		Cursor cursor = null;

		if(getSQLiteDatabase() == null)
		{
			Log.println(Log.INFO, getClass().toString(), "doInBackground() getSQLiteDatabase() - returned null.");
			return false;
		}		

		try
		{
			if(getSQLiteDatabase() != null)
			{
				Log.println(Log.INFO, getClass().toString(), "doInBackground() " + getSqlCommand());

				ArrayList<String> row;
				cursor = (getSQLiteDatabase().rawQuery(getSqlCommand(), null));

				setDatabaseQueryResult(new DatabaseQueryResult());
				getDatabaseQueryResult().setTableName(getTableName());

				if (cursor.getCount() > 0)
				{
					cursor.moveToFirst();

					// first off, setup the column name and type, by using the first row.
					for(int i = 0; i < cursor.getColumnCount(); i++)
					{
						getDatabaseQueryResult().getColumnNames().add(cursor.getColumnName(i));
						getDatabaseQueryResult().getColumnTypes().add(cursor.getType(i));
					}

					// reset the cursor
					cursor.moveToFirst();
					do
					{
						row = new ArrayList<String>();
						for(int i = 0; i < cursor.getColumnCount(); i++)
						{
							row.add(cursor.getString(i));
						}
						getDatabaseQueryResult().getDataRows().add(row);
						//						Log.println(Log.INFO, getClass().toString(), row[0]);
					}
					while (cursor.moveToNext());
				}
			}
			success = true;
		}
		catch (Exception e)
		{
			setSqlError(e.getMessage());
			Log.println(Log.ERROR, getClass().toString(), getSqlError());

			success = false;
		}
		finally
		{
			if(cursor != null && !cursor.isClosed())
			{
				cursor.close();
			}
		}

		return success;
	}

	public String getSqlCommand()
	{
		return sqlCommand;
	}

	public void setSqlCommand(String value) 
	{
		sqlCommand = value;
	}

	private String getTableName()
	{
		int nIndx = 0;
		String fromToken = "from";
		String sqlCmd = getSqlCommand().toLowerCase();
		String tableName = "";

		nIndx = sqlCmd.indexOf(fromToken);

		if(nIndx > -1)
		{
			tableName = sqlCmd.substring(nIndx + fromToken.length() + 1).split(" ")[0];
		}

		if(tableName.trim().length() < 1)
		{
			Log.println(Log.INFO, getClass().toString(),"getTableName() failed to determine one table name, returning blank.");
		}

		return(tableName);
	}

	public void setSQLiteDatabase(SQLiteDatabase value)
	{
		sqliteDatabase = value;
	}

	public SQLiteDatabase getSQLiteDatabase()
	{
		return sqliteDatabase;
	}

	public String getSqlError()
	{
		return sqlError;
	}

	public void setSqlError(String sqlError)
	{
		this.sqlError = sqlError;
	}

	public DatabaseQueryResult getDatabaseQueryResult()
	{
		return databaseQueryResult;
	}

	public void setDatabaseQueryResult(DatabaseQueryResult value)
	{
		databaseQueryResult = value;
	}

}
