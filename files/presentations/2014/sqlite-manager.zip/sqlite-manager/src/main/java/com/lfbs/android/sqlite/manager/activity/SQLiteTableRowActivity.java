package com.lfbs.android.sqlite.manager.activity;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

import com.lfbs.android.sqlite.R;
import com.lfbs.android.sqlite.manager.database.DatabaseQueryResult;
import com.lfbs.android.sqlite.manager.database.SQLiteDatabaseManager;
import com.lfbs.android.sqlite.manager.database.SQLiteDatabaseTask;

public class SQLiteTableRowActivity extends Activity
{
	public static final String PARM_DATABASE_QUERY_ROW_POSITION = "DatabaseQueryRowPosition";
	public static final String PARM_DATABASE_QUERY_ROW_OPERATION = "DatabaseQueryRowOperation";
	public static final String PARM_DATABASE_QUERY_RESULT = "DatabaseQueryResult";

	public static final int DATABASE_ROW_ADD = 1;
	public static final int DATABASE_ROW_EDIT = 2;
	public static final int DATABASE_ROW_DELETE = 3;

	private View statusView;
	private TextView statusMessageView;

	private int rowPosition;
	private int rowOperation;
	private DatabaseQueryResult databaseQueryResult; 

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sqlite_table_row);

		processIntentParms();
		buildUI();

		findViewById(R.id.buttonOK).setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View view)
			{
				executeRowOperation();
			}
		});
	}

	@Override public void onStart()
	{
		super.onStart();

		setStatusView(findViewById(R.id.sqlitetablerow_status));
		statusMessageView = (TextView) findViewById(R.id.sqlitetablerow_status_message);
	}

	private void processIntentParms()
	{
		setRowPosition(getIntent().getIntExtra(PARM_DATABASE_QUERY_ROW_POSITION,0));
		setRowOperation(getIntent().getIntExtra(PARM_DATABASE_QUERY_ROW_OPERATION,DATABASE_ROW_EDIT));
		setDatabaseQueryResult((DatabaseQueryResult)getIntent().getSerializableExtra(PARM_DATABASE_QUERY_RESULT));

		String title = "";

		if(getRowOperation() == DATABASE_ROW_ADD)
		{
			title += "Add ";
		}
		else if(getRowOperation() == DATABASE_ROW_DELETE)
		{
			title += "Delete ";
		}
		else if(getRowOperation() == DATABASE_ROW_EDIT)
		{
			title += "Edit ";
		}

		title = getDatabaseQueryResult().getTableName() + " - " + title; 

		setTitle(title);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		return true;
	}

	public int getRowPosition()
	{
		return rowPosition;
	}

	public void setRowPosition(int value)
	{
		rowPosition = value;
	}

	public int getRowOperation()
	{
		return rowOperation;
	}

	public void setRowOperation(int value)
	{
		rowOperation = value;
	}

	public DatabaseQueryResult getDatabaseQueryResult()
	{
		return databaseQueryResult;
	}

	public void setDatabaseQueryResult(DatabaseQueryResult value)
	{
		databaseQueryResult = value;
	}

	private void buildUI()
	{
		LinearLayout rowView = (LinearLayout)findViewById(R.id.sqlite_table_row_data);
		String label = "";
		String data = "";

		TextView txViewLabel;
		EditText txViewData;

		for(int i = 0; i < getDatabaseQueryResult().getColumnCount(); i++)
		{
			data = getDatabaseQueryResult().getColumnData(getRowPosition(),i);
			label = getDatabaseQueryResult().getColumnName(i);

			//			Log.println(Log.ERROR, getClass().toString(),label + ":" + data);

			txViewLabel = new TextView(this);
			txViewLabel.setText(label);

			rowView.addView(txViewLabel, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

			txViewData = new EditText(this);
			if(getRowOperation() != DATABASE_ROW_ADD)
			{
				txViewData.setText(data);
			}

			if((getRowOperation() == DATABASE_ROW_DELETE) || (i == 0))
			{
				// We are assuming first column is the primary key and is autoincrement 
				txViewData.setEnabled(false);
			}

			txViewData.setTag(getDatabaseQueryResult().getColumnName(i));

			rowView.addView(txViewData, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
		}
	}

	private void executeRowOperation()
	{
		String sqlCmd = null;

		// Big assumption here is that the first column is the primary key.
		// This does work for the sample database being used, to make this work in a more generic manner, one
		// would have to get some table meta data and figure this out.

		if(getRowOperation() == DATABASE_ROW_DELETE)
		{
			sqlCmd = "DELETE FROM " + getDatabaseQueryResult().getTableName() + " WHERE ";
			sqlCmd += getDatabaseQueryResult().getColumnName(0) + "=" + getDatabaseQueryResult().getColumnData(getRowPosition(),0);
		}
		else if(getRowOperation() == DATABASE_ROW_EDIT)
		{
			LinearLayout rowView = (LinearLayout)findViewById(R.id.sqlite_table_row_data);
			int viewChildrenCount = rowView.getChildCount();
			int columnCount = 0;
			View childView;			

			sqlCmd = "UPDATE " + getDatabaseQueryResult().getTableName() + " SET ";

			for(int i=0;i<viewChildrenCount;i++)
			{
				childView = rowView.getChildAt(i);
				if(childView instanceof EditText)
				{
					if(columnCount == 0)
					{
						// Don't mess with primary key
						columnCount++;
						continue;
					}

					sqlCmd += childView.getTag() + "=";
					if(getDatabaseQueryResult().getColumnType(columnCount) == DatabaseQueryResult.COLUMN_TYPE_STRING)
					{
						sqlCmd += "'";
						sqlCmd += ((EditText)childView).getText();
						sqlCmd += "'";
					}
					else if(((EditText)childView).getText().toString().trim().length() == 0)
					{
						sqlCmd += "NULL";
					}
					else
					{
						sqlCmd += ((EditText)childView).getText();
					}

					if(i < (viewChildrenCount -1))
					{
						sqlCmd += ",";
					}
					columnCount++;
				}
			}

			sqlCmd += " WHERE ";
			sqlCmd += getDatabaseQueryResult().getColumnName(0) + "=" + getDatabaseQueryResult().getColumnData(getRowPosition(),0);
		}
		else if(getRowOperation() == DATABASE_ROW_ADD)
		{
			LinearLayout rowView = (LinearLayout)findViewById(R.id.sqlite_table_row_data);
			int viewChildrenCount = rowView.getChildCount();
			int columnCount = 0;
			View childView;			
			String columns = "";
			String values = "";

			sqlCmd = "INSERT INTO " + getDatabaseQueryResult().getTableName();

			for(int i=0;i<viewChildrenCount;i++)
			{
				childView = rowView.getChildAt(i);
				if(childView instanceof EditText)
				{
					if(columnCount == 0)
					{
						// Don't mess with primary key
						columnCount++;
						continue;
					}
					columns += childView.getTag();
					if((getDatabaseQueryResult().getColumnType(columnCount) == DatabaseQueryResult.COLUMN_TYPE_STRING) ||
							(getDatabaseQueryResult().getColumnType(columnCount) == DatabaseQueryResult.COLUMN_TYPE_NULL))
					{
						values += "'";
						values += ((EditText)childView).getText();
						values += "'";
					}
					else if(((EditText)childView).getText().toString().trim().length() == 0)
					{
						values += "NULL";
					}
					else
					{
						values += ((EditText)childView).getText();
					}

					if(i < (viewChildrenCount -1))
					{
						columns += ",";
						values += ",";
					}
					columnCount++;
				}
			}

			sqlCmd += " (" + columns + ")" + " Values (" + values + ")";
		}

		statusMessageView.setText("executing " + sqlCmd);
		getStatusView().setVisibility(View.VISIBLE);

		// Setup a background job to load all the table names.
		SQLiteDatabaseTask sqliteTask = new SQLiteDatabaseTask(SQLiteDatabaseManager.getInstance().getSQLiteDatabase())
		{
			@Override
			protected void onPostExecute(Boolean result)
			{
				getStatusView().setVisibility(View.GONE);

				if(result)
				{
					Toast.makeText(getApplicationContext(), "SQL command completed successfully", Toast.LENGTH_LONG).show();
				}
				else
				{
					Log.e(SQLiteTableRowActivity.class.toString(),getSqlError());
					Toast.makeText(getApplicationContext(), getSqlError(), Toast.LENGTH_LONG).show();
				}
			}
		};

		sqliteTask.setSqlCommand(sqlCmd);
		sqliteTask.execute((Void) null);
	}

	public View getStatusView()
	{
		return statusView;
	}

	public void setStatusView(View value)
	{
		statusView = value;
	}

}
