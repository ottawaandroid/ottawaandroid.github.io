package com.lfbs.android.sqlite.manager.fragment.ui;

import java.util.ArrayList;

import android.app.Fragment;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.lfbs.android.sqlite.R;
import com.lfbs.android.sqlite.manager.adapter.SQLiteQueryResultAdapter;
import com.lfbs.android.sqlite.manager.database.DatabaseQueryResult;
import com.lfbs.android.sqlite.manager.database.SQLiteDatabaseManager;

public class SQLiteTableSummaryFragment extends Fragment
{
	private ListView sqliteTableLV;
	private SQLiteQueryResultAdapter sqliteTableDataAdapter;
	private String tableName = "";

	private final DatabaseQueryResult databaseQueryResult = new DatabaseQueryResult();

	// UI references.
	private View statusView;
	private TextView statusMessageView;
	private Handler handler;

	public SQLiteTableSummaryFragment()
	{
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState)
	{
		View view = inflater.inflate(R.layout.fragment_sqlite_table_summary,container, false);
		handler = new Handler();

		return view;
	}

	@Override public void onStart()
	{
		super.onStart();

		setStatusView(getView().findViewById(R.id.sqlitetablesummary_query_status));
		statusMessageView = (TextView) getView().findViewById(R.id.sqlitetablesummary_status_message);

		sqliteTableLV = (ListView)getView().findViewById(R.id.sqlitetablesummary_datalist);

		getStatusView().setVisibility(View.VISIBLE);

		new Thread(new Runnable() 
		{ 
			@Override
			public void run()
			{
				ArrayList<String> row = new ArrayList<String>();
				Cursor cursor = null;

				databaseQueryResult.getDataRows().add(row);
				showStatusMsg("Getting row count for " + getTableName());
				databaseQueryResult.getColumnNames().add("Row Count");

				try
				{
					cursor = SQLiteDatabaseManager.getInstance().getSQLiteDatabase().rawQuery("Select count(*) from " + getTableName(), null);

					if (cursor.getColumnCount() > 0)
					{
						// reset the cursor
						cursor.moveToFirst();

						row.add(cursor.getString(0));
					}
				}
				catch (Exception e)
				{
					Log.println(Log.ERROR, getClass().toString(),"Error geting value " + e.getMessage());
				}
				finally
				{
					if(cursor != null && !cursor.isClosed())
					{
						cursor.close();
					}
				}

				showStatusMsg("Getting indexes " + getTableName());

				try
				{
					cursor = SQLiteDatabaseManager.getInstance().getSQLiteDatabase().rawQuery("PRAGMA INDEX_LIST('" +  getTableName() + "')", null);

					if (cursor.getCount() > 0)
					{
						// reset the cursor
						cursor.moveToFirst();

						do
						{
							databaseQueryResult.getColumnNames().add("Index Sequence");
							databaseQueryResult.getColumnNames().add("Index Name");
							databaseQueryResult.getColumnNames().add("Unique");

							for(int i = 0; i < cursor.getColumnCount(); i++)
							{
								row.add(cursor.getString(i));
							}
						}
						while (cursor.moveToNext());


						row.add(cursor.getString(0));
					}
				}
				catch (Exception e)
				{
					Log.println(Log.ERROR, getClass().toString(),"Error geting value " + e.getMessage());
				}
				finally
				{
					if(cursor != null && !cursor.isClosed())
					{
						cursor.close();
					}
				}

				hideStatusMsg();
				showResults();
			}
		}).start();
	}

	public View getStatusView()
	{
		return statusView;
	}

	public void setStatusView(View value)
	{
		statusView = value;
	}

	private void showStatusMsg(final String progressMsg)
	{
		Runnable runnable = new Runnable()
		{
			@Override
			public void run()
			{
				handler.post(new Runnable()
				{ // This thread runs in the UI
					@Override
					public void run()
					{
						statusMessageView.setText(progressMsg);
					}
				});
			}
		};
		new Thread(runnable).start();
	}

	private void hideStatusMsg()
	{
		Runnable runnable = new Runnable()
		{
			@Override
			public void run()
			{
				handler.post(new Runnable()
				{ // This thread runs in the UI
					@Override
					public void run()
					{
						getStatusView().setVisibility(View.GONE);
					}
				});
			}
		};
		new Thread(runnable).start();
	}

	private void showResults()
	{
		Runnable runnable = new Runnable()
		{
			@Override
			public void run()
			{
				handler.post(new Runnable()
				{ // This thread runs in the UI
					@Override
					public void run()
					{
						sqliteTableLV.setVisibility(View.VISIBLE);

						sqliteTableDataAdapter = new SQLiteQueryResultAdapter(getActivity().getApplicationContext(),databaseQueryResult);
						sqliteTableLV.setAdapter(sqliteTableDataAdapter);
					}
				});
			}
		};
		new Thread(runnable).start();
	}

	public String getTableName()
	{
		return tableName;
	}

	public void setTableName(String value)
	{
		tableName = value;
	}

}
