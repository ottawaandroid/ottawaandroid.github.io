package com.lfbs.android.sqlite.manager.database;

import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class SQLiteDatabaseManager
{
	private static SQLiteDatabaseManager instance;
	private SQLiteDatabase sqliteDatabase;
	private String databasePath;

	private SQLiteDatabaseManager()
	{
	}

	public static synchronized SQLiteDatabaseManager getInstance()
	{
		if(instance == null)
		{
			instance = new SQLiteDatabaseManager();
		}

		return instance;
	}

	public SQLiteDatabase getSQLiteDatabase()
	{
		return sqliteDatabase;
	}

	public void setSQLiteDatabase(SQLiteDatabase value)
	{
		sqliteDatabase = value;
	}

	public String getDatabasePath()
	{
		return databasePath;
	}

	public void setDatabasePath(String value)
	{
		databasePath = value;
	}

	public void openWritableDatabase()
	{
		try 
		{
			setSQLiteDatabase(SQLiteDatabase.openDatabase(getDatabasePath(), null,SQLiteDatabase.OPEN_READWRITE));
		} 
		catch (Exception e) 
		{
			Log.println(Log.ERROR, getClass().toString(),"Error opening " + getDatabasePath() + "\n" + e.getMessage());
		}		
	}

	public void openReadOnlyDatabase()
	{
		try 
		{
			setSQLiteDatabase(SQLiteDatabase.openDatabase(getDatabasePath(), null,SQLiteDatabase.OPEN_READONLY));
		} 
		catch (Exception e) 
		{
			Log.println(Log.ERROR, getClass().toString(),"Error opening " + getDatabasePath() + "\n" + e.getMessage());
		}		
	}

	public void closeDatabase()
	{
		if(getSQLiteDatabase() != null)
		{
			if(getSQLiteDatabase().isOpen())
			{
				getSQLiteDatabase().close();
			}
		}
		setSQLiteDatabase(null);
	}

	public String getDatabaseName()
	{
		String dbName = getDatabasePath(); 

		if(dbName.lastIndexOf("/") > 0)
		{
			dbName = dbName.substring(dbName.lastIndexOf("/") + 1);
		}

		return(dbName);
	}
}
