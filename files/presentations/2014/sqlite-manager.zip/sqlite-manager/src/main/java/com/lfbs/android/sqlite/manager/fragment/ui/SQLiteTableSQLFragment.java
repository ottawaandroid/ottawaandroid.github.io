package com.lfbs.android.sqlite.manager.fragment.ui;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.lfbs.android.sqlite.R;
import com.lfbs.android.sqlite.manager.database.SQLiteDatabaseManager;
import com.lfbs.android.sqlite.manager.database.SQLiteDatabaseTask;

public class SQLiteTableSQLFragment extends Fragment
{
	private static final String TABLE_SQL = "SELECT sql FROM sqlite_master WHERE type='table' and name=";

	private String tableName = "";

	// UI references.
	private View statusView;
	private TextView statusMessageView;
	private TextView tableSQLView;

	public SQLiteTableSQLFragment()
	{
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState)
	{
		View view = inflater.inflate(R.layout.fragment_sqlite_table_sql,container, false);

		return view;
	}

	@Override 
	public void onStart()
	{
		super.onStart();

		final String sqlCmd = TABLE_SQL + "'" + getTableName() + "'";

		setStatusView(getView().findViewById(R.id.sqlitetablesql_status));
		setTableSQLView((TextView)getView().findViewById(R.id.texttablesql));
		statusMessageView = (TextView) getView().findViewById(R.id.sqlitetablesql_status_message);

		statusMessageView.setText("Getting sql for table - " + getTableName());
		getStatusView().setVisibility(View.VISIBLE);

		// Setup a background job to load all the table names.
		SQLiteDatabaseTask sqliteTask = new SQLiteDatabaseTask(SQLiteDatabaseManager.getInstance().getSQLiteDatabase())
		{
			@Override
			protected void onPostExecute(Boolean result)
			{
				getStatusView().setVisibility(View.GONE);

				if(result)
				{
					getTableSQLView().setText(getDatabaseQueryResult().getColumnData(0,0));
				}
				else
				{
					Toast.makeText(getActivity(), getSqlError(), Toast.LENGTH_LONG).show();
				}
			}
		};

		sqliteTask.setSqlCommand(sqlCmd);
		sqliteTask.execute((Void) null);
	}

	public View getStatusView()
	{
		return statusView;
	}

	public void setStatusView(View value)
	{
		statusView = value;
	}

	public TextView getTableSQLView()
	{
		return tableSQLView;
	}

	public void setTableSQLView(TextView value)
	{
		tableSQLView = value;
	}

	public String getTableName()
	{
		return tableName;
	}

	public void setTableName(String value)
	{
		tableName = value;
	}

}
