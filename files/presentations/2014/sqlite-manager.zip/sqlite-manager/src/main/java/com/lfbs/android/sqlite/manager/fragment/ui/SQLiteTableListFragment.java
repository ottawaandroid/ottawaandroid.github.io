package com.lfbs.android.sqlite.manager.fragment.ui;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.lfbs.android.sqlite.R;
import com.lfbs.android.sqlite.manager.activity.SQLiteTableActivity;
import com.lfbs.android.sqlite.manager.database.DatabaseQueryResult;
import com.lfbs.android.sqlite.manager.database.SQLiteDatabaseManager;
import com.lfbs.android.sqlite.manager.database.SQLiteDatabaseTask;

public class SQLiteTableListFragment extends Fragment
{
	private static final String TABLE_LIST_SQL = "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name";

	// UI references.
	private View statusView;
	private TextView statusMessageView;
	private ListView sqliteTableLV;
	private SQLiteTableNameAdapter sqliteTableNameAdapter;

	public SQLiteTableListFragment()
	{
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState)
	{
		View view = inflater.inflate(R.layout.fragment_sqlite_manager,container, false);

		return view;
	}

	@Override public void onStart()
	{
		super.onStart();

		sqliteTableLV = (ListView)getView().findViewById(R.id.sqlitetablelist);

		setStatusView(getView().findViewById(R.id.query_status));
		statusMessageView = (TextView) getView().findViewById(R.id.status_message);

		statusMessageView.setText("Getting table list");
		getStatusView().setVisibility(View.VISIBLE);

		// Setup a background job to load all the table names.
		SQLiteDatabaseTask sqliteTask = new SQLiteDatabaseTask(SQLiteDatabaseManager.getInstance().getSQLiteDatabase())
		{
			@Override
			protected void onPostExecute(Boolean result)
			{
				getStatusView().setVisibility(View.GONE);

				if(result)
				{
					sqliteTableLV.setVisibility(View.VISIBLE);
					setupSQLiteTableListView(getDatabaseQueryResult());				
				}
				else
				{
					Toast.makeText(getActivity(), getSqlError(), Toast.LENGTH_LONG).show();
				}
			}
		};

		sqliteTask.setSqlCommand(TABLE_LIST_SQL);
		sqliteTask.execute((Void) null);
	}

	private void setupSQLiteTableListView(DatabaseQueryResult databaseQueryResult)
	{
		String[] tableNames = new String[databaseQueryResult.getRowCount()];

		for(int i=0; i< databaseQueryResult.getRowCount(); i++)
		{
			// get the first and only column.
			tableNames[i] = databaseQueryResult.getDataRow(i).get(0);
		}

		sqliteTableNameAdapter = new SQLiteTableNameAdapter(getActivity().getApplicationContext(),R.layout.sqlite_table_name_row,tableNames);

		sqliteTableLV.setAdapter(sqliteTableNameAdapter);

		sqliteTableLV.setOnItemClickListener(new OnItemClickListener()
		{
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int selectedIndx, long duration)
			{
				Intent intent = new Intent(getActivity(),SQLiteTableActivity.class);

				//				Log.println(Log.INFO, getClass().toString(), "Selected " + dataRows.get(selectedIndx)[0]);

				intent.putExtra(SQLiteTableActivity.PARM_TABLE_NAME,sqliteTableNameAdapter.getItem(selectedIndx));
				startActivity(intent);
			}
		});
	}

	public View getStatusView()
	{
		return statusView;
	}

	public void setStatusView(View value)
	{
		statusView = value;
	}

	private class SQLiteTableNameAdapter extends ArrayAdapter<String>
	{
		private LayoutInflater layoutInflater;
		private String[] sqliteTables;
		private int resourceId;

		public SQLiteTableNameAdapter(Context ctx,int viewResourceId,String[] options)
		{
			super(ctx,viewResourceId,options);

			setLayoutInflater((LayoutInflater)ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE));
			setSQLiteTables(options);
			setResourceId(viewResourceId);
		}

		public LayoutInflater getLayoutInflater()
		{
			return layoutInflater;
		}

		public void setLayoutInflater(LayoutInflater value)
		{
			layoutInflater = value;
		}

		public String[] getSQLiteTables()
		{
			return sqliteTables;
		}

		public void setSQLiteTables(String[] value)
		{
			sqliteTables = value;
		}

		public int getResourceId()
		{
			return resourceId;
		}

		public void setResourceId(int value)
		{
			resourceId = value;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent)
		{
			convertView = getLayoutInflater().inflate(getResourceId(), null);
			TextView tv = (TextView)convertView.findViewById(R.id.sqlite_table_name_text);

			tv.setText(getItem(position));

			return convertView;
		}

		@Override
		public long getItemId(int position)
		{
			return position;
		}

		@Override
		public String getItem(int position)
		{
			return getSQLiteTables()[position];
		}

		@Override
		public int getCount()
		{
			return getSQLiteTables().length;
		}
	}

}
