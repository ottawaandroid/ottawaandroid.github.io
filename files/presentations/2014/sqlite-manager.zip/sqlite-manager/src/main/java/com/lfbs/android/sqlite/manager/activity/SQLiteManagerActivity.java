package com.lfbs.android.sqlite.manager.activity;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;

import com.lfbs.android.sqlite.R;
import com.lfbs.android.sqlite.manager.database.SQLiteDatabaseManager;
import com.lfbs.android.sqlite.manager.fragment.ui.SQLiteManagerSQLFragment;
import com.lfbs.android.sqlite.manager.fragment.ui.SQLiteManagerSummaryFragment;
import com.lfbs.android.sqlite.manager.fragment.ui.SQLiteTableListFragment;

/**
 * Activity which displays a login screen to the user, offering registration as
 * well.
 */

public class SQLiteManagerActivity extends Activity implements OnTabChangeListener
{
	public static final String PARM_NAME_SQLITE_DATABASE_PATH = "SQLiteDatabase";

	private static final String TAB_TABLE_LIST = "TabTableList";
	private static final String TAB_SUMMARY = "TabSummary";
	private static final String TAB_SQL = "TabSQL";

	private static final int TAB_INDX_TABLE_LIST = 0;
	private static final int TAB_INDX_SUMMARY = 1;
	private static final int TAB_INDX_SQL = 2;

	private TabHost tabHost;
	private int currentTab;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);

		SQLiteDatabaseManager.getInstance().setDatabasePath((String)getIntent().getSerializableExtra(PARM_NAME_SQLITE_DATABASE_PATH));
		setContentView(R.layout.activity_sqlite_manager);

		setupTabHost();
	}

	@Override
	protected void onStart()
	{
		super.onStart();

		if(!getTitle().toString().contains(SQLiteDatabaseManager.getInstance().getDatabaseName()))
		{
			setTitle(getTitle() + " - " + SQLiteDatabaseManager.getInstance().getDatabaseName());
		}

		SQLiteDatabaseManager.getInstance().openWritableDatabase();
	}

	@Override
	protected void onStop()
	{
		super.onStop();
	}

	@Override
	protected void onResume()
	{
		super.onResume();
	}

	@Override
	protected void onPause()
	{
		super.onPause();
	}

	public TabHost getTabHost()
	{
		return tabHost;
	}

	public void setTabHost(TabHost value)
	{
		tabHost = value;
	}

	public int getCurrentTab()
	{
		return currentTab;
	}

	public void setCurrentTab(int value)
	{
		currentTab = value;
	}

	private void setupTabHost()
	{
		// create the TabHost that will contain the Tabs
		setTabHost((TabHost)findViewById(android.R.id.tabhost));

		getTabHost().setup();

		getTabHost().addTab(createTab(TAB_TABLE_LIST,R.string.title_tab_sqlite_manager_table_list ,R.id.tab1));
		getTabHost().addTab(createTab(TAB_SUMMARY,R.string.title_tab_sqlite_manager_summary ,R.id.tab2));
		getTabHost().addTab(createTab(TAB_SQL,R.string.title_tab_sqlite_manager_sql ,R.id.tab3));

		getTabHost().setOnTabChangedListener(this);
		onTabChanged(TAB_TABLE_LIST);
	}

	private TabSpec createTab(String tag, int tabTitleId, int tabContentId) 
	{
		TabSpec tabSpec = getTabHost().newTabSpec(tag);
		tabSpec.setIndicator(getResources().getText(tabTitleId));
		tabSpec.setContent(tabContentId);

		return tabSpec;
	}

	@Override
	public void onTabChanged(String tabId)
	{
		if(tabId.equals(TAB_TABLE_LIST))
		{
			updateTab(tabId, R.id.tab1);
			setCurrentTab(TAB_INDX_TABLE_LIST);
			return;
		}
		else if(tabId.equals(TAB_SUMMARY))
		{
			updateTab(tabId, R.id.tab2);
			setCurrentTab(TAB_INDX_SUMMARY);
			return;
		}
		else if(tabId.equals(TAB_SQL))
		{
			updateTab(tabId, R.id.tab3);
			setCurrentTab(TAB_INDX_SQL);
			return;
		}
	}

	private void updateTab(String tabId, int placeholder) 
	{
		FragmentManager fm = getFragmentManager();
		Fragment fragmentCurrent = fm.findFragmentByTag(tabId);

		if(fragmentCurrent == null) 
		{
			if(tabId.equals(TAB_TABLE_LIST))
			{
				fragmentCurrent = new SQLiteTableListFragment();
			}
			else if(tabId.equals(TAB_SUMMARY))
			{
				fragmentCurrent = new SQLiteManagerSummaryFragment();
			}
			else if(tabId.equals(TAB_SQL))
			{
				fragmentCurrent = new SQLiteManagerSQLFragment();
			}
		}

		fm.beginTransaction().replace(placeholder,fragmentCurrent, tabId).commit();
	}

}
