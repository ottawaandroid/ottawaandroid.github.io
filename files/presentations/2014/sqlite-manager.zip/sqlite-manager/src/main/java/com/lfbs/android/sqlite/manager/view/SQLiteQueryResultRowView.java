package com.lfbs.android.sqlite.manager.view;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.lfbs.android.sqlite.R;
import com.lfbs.android.sqlite.manager.database.DatabaseQueryResult;

public class SQLiteQueryResultRowView extends LinearLayout
{
	private int position;
	private View parentView;
	private DatabaseQueryResult databaseQueryResult;

	public SQLiteQueryResultRowView(Context context,View parentView,DatabaseQueryResult databaseQueryResult, int position)
	{
		super(context);

		setDatabaseQueryResult(databaseQueryResult);

		setParentView(parentView);
		setPosition(position);

		setOrientation(VERTICAL);
		buildUI();
	}

	private void buildUI()
	{
		LinearLayout rowView = (LinearLayout)getParentView().findViewById(R.id.sqlite_query_result_row_data);
		String label = "";
		String data = "";

		TextView txViewLabel;
		TextView txViewData;

		for(int i = 0; i < getDatabaseQueryResult().getColumnCount(); i++)
		{
			data = getDatabaseQueryResult().getColumnData(getPosition(),i);
			label = getDatabaseQueryResult().getColumnName(i);

			//			Log.println(Log.ERROR, getClass().toString(),label + ":" + data);

			txViewLabel = new TextView(getContext());
			txViewLabel.setText(label);

			rowView.addView(txViewLabel, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

			txViewData = new TextView(getContext());
			txViewData.setText(data);

			rowView.addView(txViewData, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
		}
	}

	public DatabaseQueryResult getDatabaseQueryResult()
	{
		return databaseQueryResult;
	}

	public void setDatabaseQueryResult(DatabaseQueryResult value)
	{
		databaseQueryResult = value;
	}

	public void setPosition(int value)
	{
		position = value;
	}

	public int getPosition()
	{
		return(position);
	}

	public void setParentView(View value)
	{
		parentView = value;
	}

	public View getParentView()
	{
		return(parentView);
	}

}

