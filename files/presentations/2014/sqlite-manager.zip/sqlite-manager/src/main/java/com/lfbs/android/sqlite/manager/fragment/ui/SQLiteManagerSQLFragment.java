package com.lfbs.android.sqlite.manager.fragment.ui;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.lfbs.android.sqlite.R;

public class SQLiteManagerSQLFragment extends Fragment
{
	private EditText sqlTextView;

	private SQLiteQueryResultFragment queryResultFragment;

	public SQLiteManagerSQLFragment()
	{

	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState)
	{
		View view = inflater.inflate(R.layout.fragment_sqlite_manager_sql,container, false);

		setupFragment();

		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState)
	{
		super.onActivityCreated(savedInstanceState);
		// this is really important in order to save the state across screen
		// configuration changes for example
		//setRetainInstance(true);
	}

	@Override public void onStart()
	{
		super.onStart();
		setSqlTextView((EditText) getView().findViewById(R.id.editsqlquery));

		getSqlTextView().setText("Select * from sqlite_master");

		getView().findViewById(R.id.buttonExecuteSQL).setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View view)
			{
				getSQLiteQueryResultFragment().setSqlQuery(getSqlTextView().getText().toString());
				getSQLiteQueryResultFragment().getData();
			}
		});
	}

	@Override
	public void onPause()
	{
		super.onPause();
	}

	private void setupFragment()
	{
		setSQLiteQueryResultFragment((SQLiteQueryResultFragment)getFragmentManager().findFragmentById(R.id.sqlLiteQueryResultFragment));
	}

	private SQLiteQueryResultFragment getSQLiteQueryResultFragment()
	{
		return queryResultFragment;
	}

	private void setSQLiteQueryResultFragment(SQLiteQueryResultFragment value)
	{
		queryResultFragment = value;
	}

	public EditText getSqlTextView()
	{
		return sqlTextView;
	}

	public void setSqlTextView(EditText sqlTextView)
	{
		this.sqlTextView = sqlTextView;
	}


}
