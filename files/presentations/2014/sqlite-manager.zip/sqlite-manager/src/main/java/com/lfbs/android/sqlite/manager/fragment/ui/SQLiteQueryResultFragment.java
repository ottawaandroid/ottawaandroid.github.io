package com.lfbs.android.sqlite.manager.fragment.ui;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.lfbs.android.sqlite.R;
import com.lfbs.android.sqlite.manager.activity.SQLiteTableRowActivity;
import com.lfbs.android.sqlite.manager.adapter.SQLiteQueryResultAdapter;
import com.lfbs.android.sqlite.manager.database.DatabaseQueryResult;
import com.lfbs.android.sqlite.manager.database.SQLiteDatabaseManager;
import com.lfbs.android.sqlite.manager.database.SQLiteDatabaseTask;

public class SQLiteQueryResultFragment extends Fragment
{
	// UI references.
	private View statusView;
	private TextView statusMessageView;
	private ListView sqliteTableLV;
	private SQLiteQueryResultAdapter sqliteTableDataAdapter;
	private String sqlQuery;

	public SQLiteQueryResultFragment()
	{
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState)
	{
		View view = inflater.inflate(R.layout.fragment_sqlite_query_result,container, false);

		return view;
	}

	@Override public void onStart()
	{
		super.onStart();

		sqliteTableLV = (ListView)getView().findViewById(R.id.sqlitequeryresultlist);
		registerForContextMenu(sqliteTableLV);

		setStatusView(getView().findViewById(R.id.sqlitequeryresult_sql_query_status));
		setStatusMessageView((TextView) getView().findViewById(R.id.sqlitequeryresult_status_message));
		getData();
	}

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) 
	{
		super.onCreateContextMenu(menu, v, menuInfo);

		if (v.getId()==R.id.sqlitequeryresultlist) 
		{
			MenuInflater inflater = getActivity().getMenuInflater();
			inflater.inflate(R.menu.sqlite_table_operation, menu);
		}
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) 
	{
		AdapterContextMenuInfo info = (AdapterContextMenuInfo) item.getMenuInfo();
		int rowPosition = info.position;
		int rowOperation = SQLiteTableRowActivity.DATABASE_ROW_EDIT;

		if(item.getItemId() == R.id.table_action_add)
		{
			rowOperation = SQLiteTableRowActivity.DATABASE_ROW_ADD;
		}
		else if(item.getItemId() == R.id.table_action_edit)
		{
			rowOperation = SQLiteTableRowActivity.DATABASE_ROW_EDIT;
		}
		else if(item.getItemId() == R.id.table_action_delete)
		{
			rowOperation = SQLiteTableRowActivity.DATABASE_ROW_DELETE;
		}
		else
		{
			return super.onContextItemSelected(item);
		}

		Intent intent = new Intent(getActivity(),SQLiteTableRowActivity.class);

		intent.putExtra(SQLiteTableRowActivity.PARM_DATABASE_QUERY_ROW_POSITION,rowPosition);
		intent.putExtra(SQLiteTableRowActivity.PARM_DATABASE_QUERY_ROW_OPERATION,rowOperation);
		intent.putExtra(SQLiteTableRowActivity.PARM_DATABASE_QUERY_RESULT,sqliteTableDataAdapter.getDatabaseQueryResult());

		startActivity(intent);

		return(true);
	}	

	public void getData()
	{
		if((getSqlQuery() == null) || (getSqlQuery().trim().length() == 0))
		{
			return;
		}

		//		Log.println(Log.INFO, getClass().toString(), getSqlQuery());

		getStatusMessageView().setText("Getting results for - " + getSqlQuery());
		getStatusView().setVisibility(View.VISIBLE);

		// Setup a background job to load all the tables with initial values.
		SQLiteDatabaseTask sqliteTask = new SQLiteDatabaseTask(SQLiteDatabaseManager.getInstance().getSQLiteDatabase())
		{
			@Override
			protected void onPostExecute(Boolean result)
			{
				getStatusView().setVisibility(View.GONE);

				if(result)
				{
					getStatusView().setVisibility(View.GONE);

					sqliteTableLV.setVisibility(View.VISIBLE);
					setupSQLiteTableDataView(getDatabaseQueryResult());				
				}
				else
				{
					Toast.makeText(getActivity(), getSqlError(), Toast.LENGTH_LONG).show();
				}
			}
		};

		sqliteTask.setSqlCommand(getSqlQuery());
		sqliteTask.execute((Void) null);
	}

	private void setupSQLiteTableDataView(DatabaseQueryResult databaseQueryResult)
	{
		sqliteTableDataAdapter = new SQLiteQueryResultAdapter(getActivity().getApplicationContext(),databaseQueryResult);
		sqliteTableLV.setAdapter(sqliteTableDataAdapter);

		//		sqliteTableLV.setOnItemLongClickListener(new OnItemLongClickListener()
		//		{
		//			@Override
		//			public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int selectedIndx, long duration)
		//			{
		//				String msg = "";
		//
		//				for(int i=0; i < sqliteTableDataAdapter.getDatabaseQueryResult().getColumnCount(); i++)
		//				{
		//					msg += " Column - " + sqliteTableDataAdapter.getDatabaseQueryResult().getColumnName(i);
		//					msg += " Type - " + sqliteTableDataAdapter.getDatabaseQueryResult().getColumnType(i);
		//					msg += " Data -" + sqliteTableDataAdapter.getDatabaseQueryResult().getDataRow(selectedIndx).get(i) + "\n";
		//				}
		//
		//				Toast.makeText(getActivity(), msg, Toast.LENGTH_LONG).show();
		//
		//				return true;
		//			}
		//		});
	}

	public TextView getStatusMessageView()
	{
		return statusMessageView;
	}

	public void setStatusMessageView(TextView value)
	{
		statusMessageView = value;
	}

	public View getStatusView()
	{
		return statusView;
	}

	public void setStatusView(View value)
	{
		statusView = value;
	}

	public String getSqlQuery()
	{
		return sqlQuery;
	}

	public void setSqlQuery(String value)
	{
		sqlQuery = value;
	}
}
